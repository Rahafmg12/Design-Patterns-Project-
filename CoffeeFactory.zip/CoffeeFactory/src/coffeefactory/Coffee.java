package coffeefactory;

public interface Coffee {
    void make();
}